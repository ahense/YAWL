 #!/bin/bash

/root/install-yawl-hibernate.sh


sh /usr/local/tomcat/bin/catalina.sh run
